# from team_repo.assistant import PersonalAssistant
# import sys
# import os

# # Отримання поточного каталогу, де розташований ваш скрипт
# current_dir = os.path.dirname(os.path.realpath(__file__))

# team_repo_path = os.path.abspath(os.path.join(current_dir, 'team_repo'))
# sys.path.append(team_repo_path)

# def main():
#     assistant = PersonalAssistant()
#     assistant.load()
#     assistant.load_notes()
#     assistant.run()
#     return assistant










